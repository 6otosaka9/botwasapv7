# botwasapv7
This fix after baileys update
